import React from 'react';

export default function Header() {
  return (
    <>
      <header>Monitoramento Remoto - Sensor de temperatura</header>
    </>
  );
}
